import React from 'react'

export default function AllMenu() {
  return (
    <div>all</div>
  )
}
