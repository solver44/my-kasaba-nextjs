let ACCESS_TOKEN = "Ah0odmlvATuu577olbMLhn27X1E";
let REFRESH_TOKEN = "89gsuDtKxMgR3IDZmuBE9v4oFbM";
const myInitObject = { ACCESS_TOKEN, REFRESH_TOKEN, renew: false };
export default myInitObject;
